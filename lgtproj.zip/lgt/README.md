"#Lattice-Gauge-Theory" 
