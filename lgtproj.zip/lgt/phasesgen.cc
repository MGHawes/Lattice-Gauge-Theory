/*
 * phasesgen.cc
 *
 *  Created on: 4 Apr 2017
 *      Author: John
 */




