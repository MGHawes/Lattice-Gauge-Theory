/*
 * main.h
 *
 *  Created on: 4 Apr 2017
 *      Author: John
 */

#ifndef MAIN_H_
#define MAIN_H_

#include <iostream>
#include <array>
#include <string>
#include "constants.h"
#include "indexing.h"
#include "linkclass.h"
#include "wilsonwall.h"

int main();

#endif /* MAIN_H_ */
