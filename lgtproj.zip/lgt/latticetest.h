/*
 * main.h
 *
 *  Created on: 4 Apr 2017
 *      Author: John
 */

#ifndef LATTICETEST_H_
#define LATTICETEST_H_

int latticetest();

#endif /* LATTICETEST_H_ */
