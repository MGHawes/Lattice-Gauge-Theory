/*
 * indexing.h
 *
 *  Created on: 4 Apr 2017
 *      Author: John
 */

#ifndef INDEXING_H_
#define INDEXING_H_
#include <array>

int getindex(std::array<int, 4> _index);

int getplaqindex(std::array<int, 2> _wallindex);

#endif /* INDEXING_H_ */
